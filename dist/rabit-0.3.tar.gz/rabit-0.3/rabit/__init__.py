from rabit.gif import convert2gif
from rabit.rabit import Rabit

__version__ = "0.3"
__author__ = 'Acker'
