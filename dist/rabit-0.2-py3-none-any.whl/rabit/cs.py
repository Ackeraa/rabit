from rabit import Rabit

rabit = Rabit(11)
